1. Type 1 - 8 adalah daily Basis
2. Type 9 - 11 adalah monthly basis


Gambaran Perhitungan : 
- Safekeeping Fee untuk tipe 1-8 = Market value (Holding x price) pada Valuasi dan secara harian dikali oleh Custodian Rate kemudian dikali 1/360 (Marekt value x Rate x 1/360). Kemudian dalam 1 bulan, hasil kali tersebut di totalkan. Saat ini tim Support menggunakan RG baru made by Bang Izul
- Safekeeping Fee untuk tipe 9 -11 = Market value (Holding x price) pada akhir bulan kemudian dilai Custodian rate (Market value x Rate). Saat ini tim Support menggunakan RG baru made by Bang Izul
- Nilai Frekuensi dari Safkeeping fee = Market value untuk seluruh security pada hari terakhir periode Billing
- Nilai Frekuensi Trx Handling/ KSEI Fee,/ BISSSS Fee = nilai frekuensi dari SKTRAN antara system dengan AID sebagai key matching
- Amount Due Trx Handling/KSEI Fee/BISSSS Fee = hasil kali anyara nilai frekusensi dengan tarif (parametrize)
- VAT = PPH 11 % (Parameterized). Yang dikenakan PPN merupakan seluruh komponen Fee kecuali BISSSS Fee
- Safekeeping Fee KSEI = Merupakan biaya jasa penitipan KSEI yang sumber datanya dari ORCHID (keymatching ada pada fee desc cukup filter dengan 4 digit terakhir nama AID
