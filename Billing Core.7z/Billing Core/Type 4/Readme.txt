Type 4 : Ada yang antara Safekeeping fee dan 
Transaction fee dipisah karena perbedaan norek debit (EB itu trx dan Itama itu Safekeeping)