Type 6 : Ada yang Safekeeping Fee, Trx BISSSSS, 
Trx KSEI, Trx KSEI, Safekeeping KSEI (untuk nasabah yang baru trf asset)