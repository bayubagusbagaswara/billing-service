Type 1 : Ini klien yang hanya punya Safekeeping Fee,
Trx Handling, dan VAT (source safekeeping fee dll ada di sheet Excel)