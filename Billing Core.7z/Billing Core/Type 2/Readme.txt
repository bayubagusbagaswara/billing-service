Type 2 : mirip sama type 1 tapi dia ada minimum fee 
(info min fee ada di Excel sheet sebelahnya)